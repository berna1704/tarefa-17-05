
def pedir_lista_de_tarefas():
    tarefas = []
    print("Digite suas tarefas. Quando terminar, digite 'fim'.")
    
    while True:
        tarefa = input("Digite uma tarefa: ")
        if tarefa.lower() == 'fim':
            break
        tarefas.append(tarefa)
    
    return tarefas

def exibir_tarefas(tarefas):
    print("\nSua lista de tarefas em sequência:")
    for i, tarefa in enumerate(tarefas, start=1):
        print(f"{i}. {tarefa}")

def main():
    tarefas = pedir_lista_de_tarefas()
    exibir_tarefas(tarefas)

if __name__ == "__main__":
    main()